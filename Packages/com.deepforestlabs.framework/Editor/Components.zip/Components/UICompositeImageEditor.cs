#nullable enable
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;

namespace InkGames.Components
{
    [CanEditMultipleObjects]
    [CustomEditor(typeof(UICompositeImage))]
    public sealed class UICompositeImageEditor : Editor
    {
        private SerializedProperty _color = default!;
        private SerializedProperty _raycastTarget = default!;
        private SerializedProperty _sprite = default!;
        private SerializedProperty _material = default!;
        private SerializedProperty _mode = default!;
        private SerializedProperty _borderWidth = default!;
        private SerializedProperty _falloffDistance = default!;
        private SerializedProperty _modifier = default!;
        private SerializedProperty _radii = default!;
        private SerializedProperty _layers = default!;

        private ReorderableList _layersList = default!;

        private void OnEnable()
        {
            _color = serializedObject.FindProperty("m_Color");
            _raycastTarget = serializedObject.FindProperty("m_RaycastTarget");
            _sprite = serializedObject.FindProperty("m_Sprite");
            _material = serializedObject.FindProperty("m_Material");
            _mode = serializedObject.FindProperty("_mode");
            _borderWidth = serializedObject.FindProperty("_borderWidth");
            _falloffDistance = serializedObject.FindProperty("_falloffDistance");
            _modifier = serializedObject.FindProperty("_modifier");
            _radii = serializedObject.FindProperty("_radii");
            _layers = serializedObject.FindProperty("_layers");

            _layersList = new ReorderableList(serializedObject, _layers, true, true, true, true)
            {
                drawHeaderCallback = (rect) =>
                {
                    EditorGUI.LabelField(rect, "Layers");
                },
                drawElementCallback = DrawLayerElement,
                elementHeightCallback = _ => EditorGUIUtility.singleLineHeight * 6.5f
            };
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            EditorGUILayout.PropertyField(_color);
            EditorGUILayout.PropertyField(_raycastTarget);
            GUI.enabled = false;
            EditorGUILayout.PropertyField(_sprite);
            EditorGUILayout.PropertyField(_material);
            GUI.enabled = true;

            EditorGUILayout.PropertyField(_mode);
            EditorGUILayout.PropertyField(_borderWidth);
            EditorGUILayout.PropertyField(_falloffDistance);
            EditorGUILayout.PropertyField(_modifier);

            EditorGUILayout.Space(6);
            EditorGUILayout.LabelField("Corner Radii", EditorStyles.boldLabel);
            DrawRadiiFields();

            EditorGUILayout.Space(10);

            if (_mode.enumValueIndex == (int)UICompositeImageRenderMode.Baked)
            {
                _layersList.DoLayoutList();
            }

            serializedObject.ApplyModifiedProperties();
        }

        private void DrawRadiiFields()
        {
            EditorGUILayout.BeginVertical();
            {
                EditorGUILayout.BeginHorizontal();
                {
                    EditorGUILayout.PropertyField(_radii.FindPropertyRelative("x"), new GUIContent("Upper Left"));
                    EditorGUILayout.PropertyField(_radii.FindPropertyRelative("y"), new GUIContent("Upper Right"));
                }
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();
                {
                    EditorGUILayout.PropertyField(_radii.FindPropertyRelative("w"), new GUIContent("Lower Left"));
                    EditorGUILayout.PropertyField(_radii.FindPropertyRelative("z"), new GUIContent("Lower Right"));
                }
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndVertical();
        }

        private void DrawLayerElement(Rect rect, int index, bool isActive, bool isFocused)
        {
            SerializedProperty element = _layers.GetArrayElementAtIndex(index);

            SerializedProperty enabled = element.FindPropertyRelative("_enabled");
            SerializedProperty sprite = element.FindPropertyRelative("_sprite");
            SerializedProperty color = element.FindPropertyRelative("_color");
            SerializedProperty fillCenter = element.FindPropertyRelative("_fillCenter");

            float y = rect.y + 2;
            float lineHeight = EditorGUIUtility.singleLineHeight;

            EditorGUI.PropertyField(new Rect(rect.x, y, rect.width, lineHeight), enabled);
            y += lineHeight + 2;

            GUI.enabled = false;
            EditorGUI.PropertyField(new Rect(rect.x, y, rect.width, lineHeight), sprite);
            GUI.enabled = true;
            y += lineHeight + 2;

            EditorGUI.PropertyField(new Rect(rect.x, y, rect.width, lineHeight), color);
            y += lineHeight + 2;

            EditorGUI.PropertyField(new Rect(rect.x, y, rect.width, lineHeight), fillCenter);
        }
    }
}
