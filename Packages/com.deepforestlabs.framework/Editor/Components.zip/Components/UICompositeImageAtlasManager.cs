#nullable enable
using System.Collections.Generic;
using System.IO;
using Common.Logger;
using InkGames.Components.ProceduralImage;
using UnityEditor;
using UnityEngine;

namespace InkGames.Components
{
    internal sealed class UICompositeImageAtlasManager
    {
        private static UICompositeImageAtlasManager? _instance;
        public static UICompositeImageAtlasManager Instance => _instance ??= new UICompositeImageAtlasManager();
        
        private const string kBuildSelected = "Tools/Procedural Image/Build Selected";
        private const string kBuildAll = "Tools/Procedural Image/Build All";

        /*[MenuItem(kBuildSelected, true)]
        public static bool BuildSelectedValidator()
        {
            return Selection.activeObject is UICompositeImage || Selection.activeGameObject.TryGetComponent(out UICompositeImage _);
        }*/

        [MenuItem(kBuildSelected)]
        public static void BuildSelected()
        {
            if (Selection.activeGameObject != null && Selection.activeGameObject.TryGetComponent(out UICompositeImage source))
            {
                Instance.Build(source);
            }
        }

        [MenuItem(kBuildAll)]
        public static void BuildAll()
        {
            Instance.Rebuild();
        }

        public void Rebuild()
        {
            string exportDirectoryPath = AssetDatabase.GetAssetPath(UICompositeImageSettings.Instance.SearchForAssetsDirectory);
            string absoluteExportPath = Path.GetFullPath(exportDirectoryPath);

            // 1. Collect all existing *.pngs in the export directory
            string[] existingPngFiles = Directory.GetFiles(absoluteExportPath, "*.png", SearchOption.AllDirectories);
            HashSet<string> pngFilesToKeep = new HashSet<string>();

            // 2. Find all UICompositeImage components across the specified prefab directory
            string[] prefabGuids = AssetDatabase.FindAssets("t:Prefab", new[] { exportDirectoryPath });
            foreach (string guid in prefabGuids)
            {
                string prefabPath = AssetDatabase.GUIDToAssetPath(guid);
                GameObject? prefab = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
                if (prefab == null)
                {
                    continue;
                }

                UICompositeImage[] components = prefab.GetComponentsInChildren<UICompositeImage>(true);
                foreach (UICompositeImage component in components)
                {
                    // Build/overwrite sprite
                    Build(component);

                    // Mark sprite path as used
                    string spritePath = Path.Combine(exportDirectoryPath, GetSpriteName(component));
                    spritePath = Path.GetFullPath(spritePath); // Normalize
                    pngFilesToKeep.Add(spritePath);
                }
            }

            // 3. Delete any old PNG files that were not referenced
            /*foreach (string filePath in existingPngFiles)
            {
                if (!pngFilesToKeep.Contains(Path.GetFullPath(filePath)))
                {
                    File.Delete(filePath);
                }
            }*/

            // 4. Refresh once at the end
            AssetDatabase.Refresh();
        }
        
        public void Build(UICompositeImage original)
        {
            Vector4 radius = RoundRadii(original.Radii);

            int width = CalculateWidth(radius);
            int height = CalculateHeight(radius);

            if (width <= 0 || height <= 0)
            {
                Log.EditorError("Image {0} has invalid size.", AssetDatabase.GetAssetPath(original.gameObject));
                return;
            }

            int pad = Mathf.CeilToInt(original.FalloffDistance);
            width += pad * 2;
            height += pad * 2;

            (Camera cam, Canvas canvas) = SetupCaptureScene(width, height);

            GameObject instance = SetupInstance(original, canvas, radius, width, height);

            Texture2D alphaTex = CaptureAlphaTexture(cam, width, height);

            string pngPath = SaveTextureAsPNG(alphaTex, GetSpriteName(original));
            Sprite bakedSprite = ImportAsSprite(pngPath, radius);

            CleanupScene(cam, canvas, instance);

            InjectBakedSprite(original, bakedSprite);
        }

        private static Vector4 RoundRadii(Vector4 radii)
        {
            return new Vector4(
                Mathf.RoundToInt(radii.x),
                Mathf.RoundToInt(radii.y),
                Mathf.RoundToInt(radii.z),
                Mathf.RoundToInt(radii.w)
            );
        }

        private static int CalculateWidth(Vector4 radius)
        {
            return Mathf.Max(
                Mathf.CeilToInt(radius.x + radius.y),
                Mathf.CeilToInt(radius.x + radius.z),
                Mathf.CeilToInt(radius.w + radius.y),
                Mathf.CeilToInt(radius.w + radius.z)
            );
        }

        private static int CalculateHeight(Vector4 radius)
        {
            return Mathf.Max(
                Mathf.CeilToInt(radius.x + radius.w),
                Mathf.CeilToInt(radius.x + radius.z),
                Mathf.CeilToInt(radius.y + radius.w),
                Mathf.CeilToInt(radius.y + radius.z)
            );
        }

        private static (Camera, Canvas) SetupCaptureScene(int width, int height)
        {
            Camera cam = new GameObject($"{nameof(UICompositeImage)}.{nameof(Camera)}").AddComponent<Camera>();
            cam.orthographic = true;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = Color.clear;
            cam.transform.position += new Vector3(0, 0, -10);
            cam.orthographicSize = height / 2f;

            Canvas canvas = new GameObject($"{nameof(UICompositeImage)}.{nameof(Canvas)}").AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceCamera;
            canvas.worldCamera = cam;
            canvas.pixelPerfect = false;
            canvas.additionalShaderChannels |= AdditionalCanvasShaderChannels.TexCoord1 |
                                                AdditionalCanvasShaderChannels.TexCoord2 |
                                                AdditionalCanvasShaderChannels.TexCoord3;

            return (cam, canvas);
        }

        private static GameObject SetupInstance(UICompositeImage original, Canvas canvas, Vector4 radius, int width, int height)
        {
            GameObject instance = new GameObject($"{nameof(UICompositeImage)}.{GetSpriteName(original)}", typeof(RectTransform));
            RectTransform rt = instance.GetComponent<RectTransform>();
            rt.SetParent(canvas.transform, false);

            rt.anchorMin = Vector2.one * 0.5f;
            rt.anchorMax = Vector2.one * 0.5f;
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = new Vector2(width, height);

            UICompositeImage comp = instance.AddComponent<UICompositeImage>();
            comp.color = Color.white;
            comp.preserveAspect = false;
            comp.material = null;
            comp.Radii = radius;
            comp.Modifier = original.Modifier;
            comp.BorderWidth = original.BorderWidth;
            comp.FalloffDistance = original.FalloffDistance;
            comp.Mode = UICompositeImageRenderMode.Dynamic;
            comp.Update();

            return instance;
        }

        private static Texture2D CaptureAlphaTexture(Camera cam, int width, int height)
        {
            RenderTexture renderTex = new RenderTexture(width, height, 0, RenderTextureFormat.ARGB32)
            {
                filterMode = FilterMode.Point
            };

            cam.targetTexture = renderTex;
            cam.Render();

            RenderTexture.active = renderTex;

            Texture2D fullTex = new Texture2D(width, height, TextureFormat.ARGB32, false);
            fullTex.ReadPixels(new Rect(0, 0, width, height), 0, 0);
            fullTex.Apply();

            // Extract alpha
            Color32[] fullPixels = fullTex.GetPixels32();
            Color32[] alphaPixels = new Color32[fullPixels.Length];

            for (int i = 0; i < fullPixels.Length; i++)
            {
                byte r = fullPixels[i].r;
                alphaPixels[i] = new Color32(r, r, r, r);
            }

            Texture2D alphaTex = new Texture2D(width, height, TextureFormat.RGBA32, false);
            alphaTex.SetPixels32(alphaPixels);
            alphaTex.Apply();

            Object.DestroyImmediate(fullTex);
            RenderTexture.active = null;
            cam.targetTexture = null;
            Object.DestroyImmediate(renderTex);

            return alphaTex;
        }

        private static string SaveTextureAsPNG(Texture2D tex, string spriteName)
        {
            string path = Path.Combine(AssetDatabase.GetAssetPath(UICompositeImageSettings.Instance.ExportDirectory), spriteName);
            File.WriteAllBytes(path, tex.EncodeToPNG());
            AssetDatabase.ImportAsset(path);
            return path;
        }

        private static Sprite ImportAsSprite(string pngPath, Vector4 radius)
        {
            if (AssetImporter.GetAtPath(pngPath) is TextureImporter importer)
            {
                importer.textureType = TextureImporterType.Sprite;
                importer.alphaSource = TextureImporterAlphaSource.FromInput;
                importer.textureCompression = TextureImporterCompression.Uncompressed;
                importer.alphaIsTransparency = true;
                importer.sRGBTexture = true;
                importer.isReadable = true;
                importer.filterMode = FilterMode.Point;
                importer.mipmapEnabled = false;
                importer.spriteImportMode = SpriteImportMode.Single;
                Vector4 radii = RoundRadii(radius);
                importer.spriteBorder = new Vector4(
                    Mathf.Max(radii.x, radii.w), // Left
                    Mathf.Max(radii.w, radii.z), // Bottom
                    Mathf.Max(radii.y, radii.z), // Right
                    Mathf.Max(radii.x, radii.y)  // Top
                );

                importer.SetPlatformTextureSettings(new TextureImporterPlatformSettings
                {
                    format = TextureImporterFormat.Alpha8,
                    overridden = true,
                    name = "Default",
                    maxTextureSize = 512
                });

                importer.SaveAndReimport();
            }

            return AssetDatabase.LoadAssetAtPath<Sprite>(pngPath)!;
        }

        private static void CleanupScene(Camera cam, Canvas canvas, GameObject instance)
        {
            Object.DestroyImmediate(cam.gameObject);
            Object.DestroyImmediate(canvas.gameObject);
            Object.DestroyImmediate(instance);
        }

        private static void InjectBakedSprite(UICompositeImage original, Sprite bakedSprite)
        {
            Undo.RecordObject(original, "Inject Baked Sprite");

            SerializedObject so = new SerializedObject(original);

            // Update Mode
            SerializedProperty modeProp = so.FindProperty("_mode");
            modeProp.enumValueIndex = (int)UICompositeImageRenderMode.Baked;

            // Replace layers
            SerializedProperty layersProp = so.FindProperty("_layers");
            layersProp.arraySize = 1;

            SerializedProperty layerProp = layersProp.GetArrayElementAtIndex(0);
            layerProp.FindPropertyRelative("_enabled").boolValue = true;
            layerProp.FindPropertyRelative("_sprite").objectReferenceValue = bakedSprite;
            layerProp.FindPropertyRelative("_color").colorValue = Color.white;
            layerProp.FindPropertyRelative("_fillCenter").boolValue = true;
            // effects list stays empty

            so.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(original);
            PrefabUtility.RecordPrefabInstancePropertyModifications(original);
        }

        public static string GetSpriteName(UICompositeImage procImg)
        {
            Vector4 radius = RoundRadii(procImg.Radii);
            string radiusString = Mathf.Approximately(radius.x, radius.y) &&
                                  Mathf.Approximately(radius.x, radius.z) &&
                                  Mathf.Approximately(radius.x, radius.w)
                ? $"r{Mathf.RoundToInt(radius.x)}"
                : $"r{Mathf.RoundToInt(radius.x)}_{Mathf.RoundToInt(radius.y)}_{Mathf.RoundToInt(radius.z)}_{Mathf.RoundToInt(radius.w)}";

            return $"{UICompositeImageSettings.Instance.SpriteNamePrefix}_{(int)procImg.BorderWidth}_{(int)procImg.FalloffDistance}_{radiusString}.png";
        }
        
        private static int ClampRadius(float radius)
        {
            for (int i = UICompositeImageSettings.AllowedRadii.Length - 1; i >= 0; i--)
            {
                if (radius >= UICompositeImageSettings.AllowedRadii[i])
                {
                    return UICompositeImageSettings.AllowedRadii[i];
                }
            }

            return -1;
        }
        
        private static float CalculatePixelScale(float requestedRadius, int clampedRadius)
        {
            return Mathf.Max(0.0001f, requestedRadius / clampedRadius);
        }
    }
}